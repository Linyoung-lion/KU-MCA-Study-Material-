# KU MCA Study Material — Cybersecurity Unit 1

A static GitHub Pages website for MCA Semester 1 Cybersecurity Unit 1.

## Files
- `index.html` — website structure/content
- `style.css` — notebook-inspired responsive design
- `script.js` — search, filters, and attack accordions

## GitHub Pages
1. Create a GitHub repository.
2. Upload these three files to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub Pages publishes the static HTML/CSS/JavaScript site.

GitHub Pages uses `index.html` as an entry file for a branch-based site.
